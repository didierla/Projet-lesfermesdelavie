const express = require('express');
const router = express.Router();
const multer = require('multer');
const fs = require('fs');
const { exec } = require('child_process');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const storage = multer.memoryStorage();
const upload = multer({ storage });

router.post('/transcrire', upload.single('audio'), (req, res) => {
  const fichierWebm = path.join('uploads', `${uuidv4()}.webm`);
  const fichierWav = `${fichierWebm}-${uuidv4()}.wav`;
  const transcriptionPath = `${fichierWav}.txt`;

  const buffer = req.file?.buffer;
  console.log("📦 Taille du buffer reçu :", buffer?.length || 'inconnu');
  console.log("📂 Fichier brut reçu :", req.file);


  if (!buffer) {
    return res.status(400).json({ erreur: "Fichier audio non reçu." });
  }

  fs.writeFile(fichierWebm, buffer, async (err) => {
    if (err) {
      console.error("❌ Erreur écriture fichier webm :", err);
      return res.status(500).json({ erreur: "Impossible d'écrire le fichier audio" });
    }

    console.log("📁 Fichier .webm écrit :", fichierWebm);

    const conversionCmd = `ffmpeg -i ${fichierWebm} -ar 16000 -ac 1 ${fichierWav}`;
    console.log("🔄 Commande FFmpeg :", conversionCmd);

    exec(conversionCmd, (err) => {
      if (err) {
        console.error("❌ Erreur conversion FFmpeg :", err);
        return res.status(500).json({ erreur: "Erreur conversion audio" });
      }

      const whisperCmd = `whisper ${fichierWav} --language French --model small --output_format txt`;
      console.log("🧠 Commande Whisper :", whisperCmd);

      exec(whisperCmd, (err, stdout, stderr) => {
        console.log("📤 stdout :", stdout);
        console.log("📥 stderr :", stderr);

        if (err) {
          console.error("❌ Erreur Whisper :", err);
          return res.status(500).json({ erreur: "Erreur transcription" });
        }

        fs.readFile(transcriptionPath, 'utf8', (err, data) => {
          if (err) {
            console.error("❌ Erreur lecture texte :", err);
            return res.status(500).json({ erreur: "Impossible de lire la transcription" });
          }

          res.json({ transcription: data.trim() });

          fs.unlink(fichierWebm, () => {});
          fs.unlink(fichierWav, () => {});
          fs.unlink(transcriptionPath, () => {});
        });
      });
    });
  });
});

module.exports = router;