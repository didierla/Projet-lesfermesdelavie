// serveur-api/server.js

const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();
const PORT = 8001;

app.use(cors());
app.use(bodyParser.json());

let taches = [];
let nextId = 1;

// Route pour créer une tâche
app.post("/api/taches", (req, res) => {
  const { nom, description } = req.body;

  if (!nom || !description) {
    return res.status(400).json({ error: "Nom et description requis" });
  }

  const nouvelleTache = {
    id: nextId++,
    nom,
    description,
    dateCreation: new Date(),
  };

  taches.push(nouvelleTache);

  res.status(201).json(nouvelleTache);
});

// Route pour voir les tâches
app.get("/api/taches", (req, res) => {
  res.json(taches);
});

app.listen(PORT, () => {
  console.log(`✅ Serveur API démarré sur http://localhost:${PORT}`);
});
