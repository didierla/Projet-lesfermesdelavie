const express = require('express');
const cors = require('cors');
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
const transcriptionRoute = require('./routes/transcrire');
const db = require('./db');


console.log("▶️ Ce que j'importe :", transcriptionRoute);

app.use(cors());
app.use('/api', transcriptionRoute);

const PORT = 3001;
app.listen(PORT, () => {
  console.log(`✅ Serveur Express en écoute sur http://localhost:${PORT}`);
});

app.get('/test-db', (req, res) => {
  db.query('SELECT 1 + 1 AS result', (err, results) => {
    if (err) return res.status(500).send('Erreur requête');
    res.send(`Résultat de la requête test : ${results[0].result}`);
  });
});

app.post('/taches', (req, res) => {
  const { nom, description, documentation_url, activable, nb_personnes } = req.body;
  const sql = `
    INSERT INTO taches (nom, description, documentation_url, activable, nb_personnes)
    VALUES (?, ?, ?, ?, ?)
  `;
  db.query(sql, [nom, description, documentation_url, activable, nb_personnes], (err, result) => {
    if (err) {
      console.error("❌ Erreur d'insertion :", err);
      res.status(500).json({ message: "Erreur serveur" });
    } else {
      res.status(201).json({ message: "Tâche créée", id: result.insertId });
    }
  });
});
