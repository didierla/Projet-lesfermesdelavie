import React from "react";
import { useNavigate } from "react-router-dom";

export default function Accueil() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 text-center p-8">
      <h1 className="text-4xl font-bold mb-6">Bienvenue sur les Fermes de la Vie</h1>
      <p className="mb-8 text-lg">Choisissez une direction pour commencer :</p>
      <div className="space-y-4">
        <button
          onClick={() => navigate("/tour-de-controle")}
          className="bg-green-600 text-white px-6 py-3 rounded shadow hover:bg-green-700"
        >
          Gérer le projet
        </button>
        <button
          onClick={() => alert("Module IA non disponible pour le moment.")}
          className="bg-blue-600 text-white px-6 py-3 rounded shadow hover:bg-blue-700"
        >
          Poser des questions à l’IA
        </button>
        <button
          onClick={() => alert("Module planification à venir.")}
          className="bg-purple-600 text-white px-6 py-3 rounded shadow hover:bg-purple-700"
        >
          Planifier mon travail
        </button>
      </div>
    </div>
  );
}
