import React from "react";

export default function GestionHumains() {
  return (
    <div className="max-w-3xl mx-auto p-6 bg-white rounded shadow">
      <h2 className="text-2xl font-bold mb-4 text-center">Gestion des Humains</h2>
      <p className="text-gray-700">
        Cette section contiendra les outils pour :
      </p>
      <ul className="list-disc list-inside mt-4 space-y-1 text-gray-800">
        <li>Créer/modifier les candidats</li>
        <li>Afficher la liste des candidats</li>
        <li>Gérer les fermiers d’une ferme</li>
        <li>Suivre les groupes organisationnels humains</li>
        <li>Traiter les candidats rejetés</li>
      </ul>
      <p className="mt-4 text-sm text-gray-500 italic">
        (Fonctionnalités à venir)
      </p>
    </div>
  );
}
