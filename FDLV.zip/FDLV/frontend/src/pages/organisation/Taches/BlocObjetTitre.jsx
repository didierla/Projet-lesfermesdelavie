import React from "react";

const BlocObjetTitre = ({ titre, bouton }) => {
  const boutonsPresets = {
    Bouton1: {
      texte: "Appeler l'IA",
      onClick: () => console.log("Appel à l'IA déclenché")
    },
    Bouton2: {
      texte: "Documenter",
      onClick: () => console.log("Documentation en cours")
    },
    Bouton3: {
      texte: "Retour",
      onClick: () => console.log("Retour en arrière")
    }
  };

  const boutonConfig = boutonsPresets[bouton];

  return (
    <div className="bg-blue-50 border-l-4 border-blue-400 p-6 rounded space-y-4">
      <h1 className="text-3xl font-bold text-blue-800">{titre}</h1>
      {boutonConfig && (
        <button
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          onClick={boutonConfig.onClick}
        >
          {boutonConfig.texte}
        </button>
      )}
    </div>
  );
};

export default BlocObjetTitre;