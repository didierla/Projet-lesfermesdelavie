// src/pages/organisation/taches/AffecterFermier.jsx
import React from "react";
export default function AffecterFermier() {
  return <div>Affectation d’une tâche à un fermier</div>;
}