// src/pages/organisation/taches/RetirerDomaine.jsx
import React from "react";
export default function RetirerDomaine() {
  return <div>Suppression d’une tâche d’un domaine</div>;
}
