// src/pages/organisation/taches/CreerTache.jsx
import React, { useState, useEffect } from "react";
import axios from "axios";

export default function CreerTache() {
  const [nom, setNom] = useState("");
  const [description, setDescription] = useState("");
  const [domaine, setDomaine] = useState("");
  const [procedure, setProcedure] = useState("");
  const [fermier, setFermier] = useState("");
  const [priorite, setPriorite] = useState("normale");
  const [typeTache, setTypeTache] = useState("");
  const [dateLimite, setDateLimite] = useState("");

  const [contexte, setContexte] = useState("");
  const [conditions, setConditions] = useState("");
  const [objectif, setObjectif] = useState("");
  const [competences, setCompetences] = useState("");
  const [outils, setOutils] = useState("");
  const [risques, setRisques] = useState("");
  const [tachesLiees, setTachesLiees] = useState("");

  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:8001/api/taches", {
        nom,
        description,
        domaine,
        procedure,
        fermier,
        priorite,
        dateLimite,
        typeTache,
        contexte,
        conditions,
        objectif,
        competences,
        outils,
        risques,
        tachesLiees,
      });
      setMessage("✅ Tâche créée avec succès !");
    } catch (error) {
      setMessage("❌ Erreur lors de la création de la tâche.");
    }
  };

  return (
    <div className="max-w-5xl mx-auto p-8 bg-gradient-to-br from-green-100 to-white shadow-xl rounded-2xl mt-12 border border-green-200">
      <h1 className="text-3xl font-bold mb-6 text-center text-green-800">Créer une nouvelle tâche</h1>
      {message && (
        <div className="mb-6 text-center font-semibold text-green-700 animate-pulse">
          {message}
        </div>
      )}
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[
            { label: "Nom de la tâche", value: nom, setter: setNom },
            { label: "Description", value: description, setter: setDescription, type: "textarea", span: 2 },
            { label: "Domaine", value: domaine, setter: setDomaine },
            { label: "Procédure", value: procedure, setter: setProcedure },
            { label: "Fermier concerné", value: fermier, setter: setFermier },
            { label: "Date limite", value: dateLimite, setter: setDateLimite, type: "date" },
          ].map(({ label, value, setter, type = "text", span }, index) => (
            <div key={index} className={`md:col-span-${span || 1}`}>
              <label className="block text-sm font-medium text-gray-700 mb-1 w-40 inline-block">
                {label}
              </label>
              {type === "textarea" ? (
                <textarea
                  className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-green-400"
                  value={value}
                  onChange={(e) => setter(e.target.value)}
                  rows="4"
                />
              ) : (
                <input
                  type={type}
                  className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-green-400"
                  value={value}
                  onChange={(e) => setter(e.target.value)}
                />
              )}
            </div>
          ))}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1 w-40 inline-block">Priorité</label>
            <select className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-green-400" value={priorite} onChange={(e) => setPriorite(e.target.value)}>
              <option value="faible">Faible</option>
              <option value="normale">Normale</option>
              <option value="élevée">Élevée</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1 w-40 inline-block">Type de tâche</label>
            <select className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-green-400" value={typeTache} onChange={(e) => setTypeTache(e.target.value)}>
              <option value="">-- Sélectionner --</option>
              <option value="ponctuelle">Ponctuelle</option>
              <option value="récurrente">Récurrente</option>
              <option value="critique">Critique</option>
              <option value="exploratoire">Exploratoire</option>
            </select>
          </div>
        </div>

        <hr className="my-6 border-t border-green-300" />
        <h2 className="text-xl font-bold text-green-800 mb-4">Connaissances contextuelles</h2>
        <div className="space-y-4">
          {[{ placeholder: "Contexte", value: contexte, setter: setContexte },
            { placeholder: "Conditions de réalisation", value: conditions, setter: setConditions },
            { placeholder: "Objectif attendu", value: objectif, setter: setObjectif },
            { placeholder: "Compétences requises", value: competences, setter: setCompetences },
            { placeholder: "Outils nécessaires", value: outils, setter: setOutils },
            { placeholder: "Risques particuliers", value: risques, setter: setRisques },
            { placeholder: "Tâches précédentes ou suivantes", value: tachesLiees, setter: setTachesLiees }
          ].map(({ placeholder, value, setter }, index) => (
            <textarea key={index} placeholder={placeholder} value={value} onChange={(e) => setter(e.target.value)} className="w-full p-3 border border-gray-300 rounded-lg" rows="2" />
          ))}
        </div>

        <button type="submit" className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-lg shadow-md transition duration-300 mt-6">
          ✅ Créer la tâche
        </button>
      </form>
    </div>
  );
}
