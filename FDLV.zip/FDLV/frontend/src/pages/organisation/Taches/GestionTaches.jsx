import React from "react";
import { Link } from "react-router-dom";

export default function GestionTaches() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Gestion des tâches</h1>
      <ul className="space-y-2 list-disc list-inside">
        <li><Link to="/organisation/taches/creer">Création d’une tâche</Link></li>
        <li><Link to="/organisation/taches/modifier">Modification d’une tâche</Link></li>
        <li><Link to="/organisation/taches/supprimer">Suppression d’une tâche</Link></li>
        <li><Link to="/organisation/taches/affecter-fermier">Affectation à un fermier</Link></li>
        <li><Link to="/organisation/taches/liste-fermier">Liste des tâches d’un fermier</Link></li>
        <li><Link to="/organisation/taches/liste-procedure">Liste des tâches d’une procédure</Link></li>
        <li><Link to="/organisation/taches/affecter-procedure">Affectation à une procédure</Link></li>
        <li><Link to="/organisation/taches/retirer-procedure">Retrait d’une tâche d’une procédure</Link></li>
        <li><Link to="/organisation/taches/affecter-domaine">Affectation à un domaine</Link></li>
        <li><Link to="/organisation/taches/retirer-domaine">Retrait d’un domaine</Link></li>
      </ul>
    </div>
  );
}
