
import React, { useState } from "react";
import axios from "axios";

const BlocObjetConclusion = () => {
  const [resultatIA, setResultatIA] = useState("");
  const [loading, setLoading] = useState(false);

  const lancerAnalyseIA = () => {
    setLoading(true);
    axios.get("/api/tache/analyse")
      .then(res => setResultatIA(res.data.reponse))
      .catch(() => setResultatIA("Erreur lors de l'appel à l'IA."))
      .finally(() => setLoading(false));
  };

  return (
    <div className="bg-gray-50 border-l-4 border-gray-400 p-6 rounded mt-10 space-y-4">
      <h2 className="text-xl font-bold text-gray-700">🧠 Synthèse intelligente</h2>
      <button className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700" onClick={lancerAnalyseIA} disabled={loading}>
        {loading ? "Analyse en cours..." : "🤖 Lancer l'IA"}
      </button>
      {resultatIA && (
        <div className="mt-4 bg-white border p-4 rounded shadow">
          <p>{resultatIA}</p>
        </div>
      )}
    </div>
  );
};

export default BlocObjetConclusion;
