// src/pages/organisation/taches/RetirerProcedure.jsx
import React from "react";
export default function RetirerProcedure() {
  return <div>Suppression d’une tâche d’une procédure</div>;
}
