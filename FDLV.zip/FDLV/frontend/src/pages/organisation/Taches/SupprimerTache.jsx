// src/pages/organisation/taches/SupprimerTache.jsx
import React from "react";
export default function SupprimerTache() {
  return <div>Suppression d’une tâche</div>;
}