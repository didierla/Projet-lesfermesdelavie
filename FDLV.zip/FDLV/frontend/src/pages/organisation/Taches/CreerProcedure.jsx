import React, { useState } from "react";
import BlocObjetComposant from "./BlocObjetComposant";
import BlocObjetTitre from "./BlocObjetTitre";
import BlocObjet from "./BlocObjet";
import BlocObjetConclusion from "./BlocObjetConclusion";

const CreerProcedure = () => {
  const [nomProcedure, setNomProcedure] = useState(null);

  const handleValidation = (nom) => {
    setNomProcedure(nom);
  };

  return (
    <div className="space-y-10 p-6">
      <BlocObjetComposant table="Procedures" onValidation={handleValidation} />

      {nomProcedure && (
        <>
          <BlocObjetTitre 
            titre={`Création ou modification de la procédure : ${nomProcedure}`} 
            bouton="Bouton1"
          />
		  
      <BlocDocumentation nomObjet="la procédure" />

		  <BlocObjet
			titre="🌍 Procedure"
			nomObjet="Procedure"
			proceduresTable="procedures"
			infosTable="Nil"
		  />

          <BlocObjetConclusion 
            nombreBoutons={2} 
            boutons={["SyntheseIA", "Evaluer"]} 
          />
        </>
      )}
    </div>
  );
};

export default CreerProcedure;
