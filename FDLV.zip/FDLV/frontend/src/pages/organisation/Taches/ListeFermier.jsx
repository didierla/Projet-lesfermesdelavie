// src/pages/organisation/taches/ListeFermier.jsx
import React from "react";
export default function ListeFermier() {
  return <div>Liste des tâches d’un fermier</div>;
}