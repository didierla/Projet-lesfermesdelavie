const AfficherTache = ({ tache }) => {
  if (!tache) return <p className="text-center text-gray-500">Aucune tâche à afficher.</p>;

  return (
    <div className="max-w-xl mx-auto mt-10 p-6 bg-white border rounded shadow">
      <h2 className="text-2xl font-bold text-green-700 mb-4">{tache.nom}</h2>
      <p className="mb-2"><strong>Description :</strong> {tache.description}</p>
      <p className="mb-2"><strong>Documentation :</strong> <a href={tache.documentation_url} className="text-blue-500 underline">{tache.documentation_url}</a></p>
      <p className="mb-2"><strong>Voile :</strong> {tache.voile_id}</p>
      <p className="mb-2"><strong>Activable :</strong> {tache.activable ? "Oui" : "Non"}</p>
    </div>
  );
};

export default AfficherTache;