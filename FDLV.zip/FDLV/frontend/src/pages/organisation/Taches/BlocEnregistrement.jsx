import React, { useState, useEffect } from "react";
import axios from "axios";

const languesDisponibles = ["fr", "en", "de"];

const BlocEnregistrement = ({ table, colonnesSimples, colonnesMultilangues, valeursInitiales = {} }) => {
  const [valeurs, setValeurs] = useState({
    ...valeursInitiales,
    auteur: "utilisateur_actuel",
    date_creation: new Date().toISOString().slice(0, 19).replace("T", " ")
  });
  const [valeursMultilang, setValeursMultilang] = useState(() => {
    const init = {};
    colonnesMultilangues.forEach((champ) => {
      init[champ] = {};
      languesDisponibles.forEach((lang) => {
        init[champ][lang] = "";
      });
    });
    return init;
  });

  const [message, setMessage] = useState("");
  const [discussion, setDiscussion] = useState("");
  const [discussionHistorique, setDiscussionHistorique] = useState([]);

  useEffect(() => {
    setValeurs((prev) => ({
      ...prev,
      ...valeursInitiales,
    }));
  }, [valeursInitiales]);

  const handleChange = (champ, value) => {
    setValeurs((prev) => ({ ...prev, [champ]: value }));
  };

  const handleMultilangChange = (champ, lang, value) => {
    setValeursMultilang((prev) => ({
      ...prev,
      [champ]: {
        ...prev[champ],
        [lang]: value,
      },
    }));
  };

  const handleSubmit = async () => {
    try {
      await axios.post(`/api/${table}`, valeurs);

      for (const champ of colonnesMultilangues) {
        await axios.post(`/api/langues`, {
          clef: valeurs.id || "temp-id",
          champ,
          valeurs: valeursMultilang[champ],
        });
      }

      if (discussion.trim()) {
        await axios.post(`/api/discussion`, {
          objet_id: valeurs.id || "temp-id",
          objet_type: table,
          auteur: valeurs.auteur,
          message: discussion,
          date: new Date().toISOString(),
        });
      }
      setMessage("✅ Enregistrement réussi !");
      setDiscussion("");
    } catch (err) {
      console.error(err);
      setMessage("❌ Échec de l'enregistrement.");
    }
  };

  const fetchDiscussions = async () => {
    try {
      const res = await axios.get(`/api/discussion/${table}/${valeurs.id}`);
      setDiscussionHistorique(res.data);
    } catch (err) {
      console.warn("Pas d'historique de discussion disponible");
    }
  };

  useEffect(() => {
    if (valeurs.id) fetchDiscussions();
  }, [valeurs.id]);

  return (
    <div className="p-6 bg-green-50 border border-green-300 rounded-xl shadow space-y-6">
      <h2 className="text-xl font-bold text-green-800">📝 Création dans la table {table}</h2>

      {colonnesMultilangues.map((champ) => (
        <div key={champ}>
          <label className="block font-semibold mb-1 capitalize">{champ} :</label>
          <div className="grid grid-cols-3 gap-4">
            {languesDisponibles.map((lang) => (
              <input
                key={lang}
                placeholder={lang.toUpperCase()}
                className="border p-2 rounded"
                value={valeursMultilang[champ][lang] || ""}
                onChange={(e) => handleMultilangChange(champ, lang, e.target.value)}
              />
            ))}
          </div>
        </div>
      ))}

      {colonnesSimples.map((champ) => (
        <div key={champ}>
          <label className="block font-semibold mb-1 capitalize">{champ} :</label>
          <input
            type="text"
            className="w-full border p-2 rounded"
            value={valeurs[champ] || ""}
            onChange={(e) => handleChange(champ, e.target.value)}
          />
        </div>
      ))}

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block font-semibold mb-1">Auteur :</label>
          <input
            type="text"
            className=