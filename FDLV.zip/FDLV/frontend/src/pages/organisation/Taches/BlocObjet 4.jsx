import React, { useState, useEffect } from "react";
import axios from "axios";

const BlocObjet = ({ titre, nomObjet, proceduresTable, infosTable }) => {
  const [listeAffectees, setListeAffectees] = useState([]);
  const [listeProcedures, setListeProcedures] = useState([]);
  const [listeInfos, setListeInfos] = useState([]);
  const [procedure, setProcedure] = useState("");
  const [info, setInfo] = useState("");

  useEffect(() => {
    axios.get(`/api/tache/${nomObjet}`).then(res => setListeAffectees(res.data)).catch(() => {});
    if (proceduresTable !== "Nil") {
      axios.get(`/api/${proceduresTable}`).then(res => setListeProcedures(res.data)).catch(() => {});
    }
    if (infosTable !== "Nil") {
      axios.get(`/api/${infosTable}`).then(res => setListeInfos(res.data)).catch(() => {});
    }
  }, [nomObjet, proceduresTable, infosTable]);

  const affecterInfo = () => {
    if ((proceduresTable === "Nil" || procedure) && (infosTable === "Nil" || info)) {
      axios.post(`/api/tache/${nomObjet}/ajouter`, {
        procedure: proceduresTable === "Nil" ? null : procedure,
        info: infosTable === "Nil" ? null : info
      })
        .then(() => {
          setListeAffectees(prev => [...prev, { procedure, info }]);
          setProcedure("");
          setInfo("");
        })
        .catch(err => console.error(err));
    }
  };

  const infosLiees = infosTable !== "Nil" ? listeInfos.filter(i => i.procedure === procedure) : [];

  const afficherColonnes = proceduresTable !== "Nil" || infosTable !== "Nil";

  return (
    <div className="p-6 bg-yellow-50 border-2 border-yellow-300 rounded-xl shadow space-y-6">
      <h2 className="text-xl font-bold text-yellow-800">{titre}</h2>

      <div>
        <h3 className="font-semibold mb-2">📋 {nomObjet} affectés à la tâche :</h3>
        {listeAffectees.length === 0 ? (
          <p className="text-gray-600">Aucun {nomObjet} encore affecté.</p>
        ) : (
          <ul className="list-disc pl-5 text-gray-800">
            {listeAffectees.map((el, i) => (
              <li key={i}>{el.procedure}{infosTable !== "Nil" && el.info ? ` → ${el.info}` : ""}</li>
            ))}
          </ul>
        )}
      </div>

      <div className="flex justify-between items-center space-x-4">
        <button onClick={affecterInfo} className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
          📌 Affecter le {nomObjet} à la tâche
        </button>
        <button type="button" className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
          ➕ Créer un {nomObjet}
        </button>
      </div>

      {afficherColonnes && (
        <div className={`grid gap-4 ${proceduresTable !== "Nil" && infosTable !== "Nil" ? "md:grid-cols-2" : "grid-cols-1"}`}>
          {proceduresTable !== "Nil" && (
            <div>
              <label className="block font-semibold mb-1">{proceduresTable.charAt(0).toUpperCase() + proceduresTable.slice(1)} :</label>
              <select className="w-full border p-2 rounded" value={procedure} onChange={(e) => { setProcedure(e.target.value); setInfo(""); }}>
                <option value="">-- Choisir --</option>
                {listeProcedures.map((p, i) => <option key={i} value={p.nom}>{p.nom}</option>)}
              </select>
            </div>
          )}

          {infosTable !== "Nil" && (
            <div>
              <label className="block font-semibold mb-1">Information spécifique :</label>
              <select className="w-full border p-2 rounded" value={info} onChange={(e) => setInfo(e.target.value)} disabled={proceduresTable !== "Nil" && !procedure}>
                <option value="">-- Choisir --</option>
                {infosLiees.map((inf, i) => <option key={i} value={inf.nom}>{inf.nom}</option>)}
              </select>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default BlocObjet;
