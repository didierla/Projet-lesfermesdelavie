import React, { useState } from "react";
import BlocObjetComposant from "./BlocObjetComposant";
import BlocObjetTitre from "./BlocObjetTitre";
import BlocObjet from "./BlocObjet";
import BlocObjetConclusion from "./BlocObjetConclusion";
import BlocDocumentation from "./BlocDocumentation"; // ← N'oublie pas d'importer
import BlocEnregistrement from "./BlocEnregistrement";

const CreerTache = () => {
  const [nomTache, setNomTache] = useState(null);

  const handleValidation = (nom) => {
    setNomTache(nom);
  };

  const [afficherEnregistrement, setAfficherEnregistrement] = useState(false);

  return (
    <div className="space-y-10 p-6">
      <BlocObjetComposant table="taches" onValidation={handleValidation} />

      {nomTache && (
        <>
          <BlocObjetTitre 
            titre={`Création ou modification de la tâche : ${nomTache}`} 
            bouton="AppelIA" 
          />

          <BlocDocumentation nomObjet="la tâche" />

          <BlocObjet
            titre="🌍 Procédures"
            nomObjet="Procedure"
            proceduresTable="procedures"
            infosTable="Nil"
          />

          <BlocObjet
            titre="📥 Informations entrantes"
            nomObjet="informations_entrantes"
            proceduresTable="procedures"
            infosTable="informations_sortantes"
          />

          <BlocObjet
            titre="📤 Informations sortantes"
            nomObjet="informations_sortantes"
            proceduresTable="procedures"
            infosTable="informations_entrantes"
          />

          <BlocObjet
            titre="📊 Données"
            nomObjet="donnees"
            proceduresTable="procedures"
            infosTable="informations_sortantes"
          />

          <BlocObjet
            titre="🌍 Domaines"
            nomObjet="domaines"
            proceduresTable="domaines"
            infosTable="Nil"
          />

          <BlocObjet
            titre="🧭 Nappes"
            nomObjet="nappes"
            proceduresTable="Nil"
            infosTable="Nil"
          />

          <BlocObjetConclusion 
            nombreBoutons={2} 
            boutons={["SyntheseIA", "Evaluer"]} 
          />

         <button
          className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700"
          onClick={() => setAfficherEnregistrement(true)}
        >
          💾 Enregistrement Taches
        </button>
        {afficherEnregistrement && (
        <BlocEnregistrement
          table="taches"
          colonnes={["nom", "description", "auteur", "date_creation"]}
          />
          )}

        </>
      )}
    </div>
  );
};

export default CreerTache;
