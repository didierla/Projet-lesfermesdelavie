// src/pages/organisation/taches/ListeProcedure.jsx
import React from "react";
export default function ListeProcedure() {
  return <div>Liste des tâches d’une procédure</div>;
}