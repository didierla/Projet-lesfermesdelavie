// src/pages/organisation/taches/AffecterProcedure.jsx
import React from "react";
export default function AffecterProcedure() {
  return <div>Affectation d’une tâche à une procédure</div>;
}