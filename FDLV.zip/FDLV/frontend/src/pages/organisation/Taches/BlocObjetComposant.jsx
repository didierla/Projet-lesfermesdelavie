import React, { useState } from "react";

const BlocObjetComposant = ({ table, onValidation }) => {
  const [nom, setNom] = useState("");

  const verifier = () => {
    if (nom.trim() !== "") {
      onValidation(nom); // Simule la validation immédiate
    }
  };

  return (
    <div className="p-4 bg-green-100 border border-green-300 rounded mb-6">
      <h2 className="text-lg font-bold text-green-800 mb-2">Entrer le nom de la tâche</h2>
      <div className="flex space-x-2">
        <input
          className="flex-1 p-2 border rounded"
          value={nom}
          onChange={(e) => setNom(e.target.value)}
          placeholder="Nom de la tâche"
        />
        <button
          onClick={verifier}
          className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
        >
          Vérifier
        </button>
      </div>
    </div>
  );
};

export default BlocObjetComposant;
