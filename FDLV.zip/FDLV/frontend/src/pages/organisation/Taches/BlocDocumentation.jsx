import React, { useState } from "react";

const BlocDocumentation = ({ nomObjet }) => {
  const [description, setDescription] = useState("");

  const handleChange = (e) => {
    setDescription(e.target.value);
  };

  const handleSave = () => {
    console.log(`📄 Description enregistrée pour ${nomObjet} :`, description);
    // 👉 Remplacer par un appel à l'API si tu veux l'enregistrer en base :
    // axios.post(`/api/${nomObjet}/description`, { description })
  };

  return (
    <div className="p-6 bg-white border-2 border-gray-300 rounded-xl shadow space-y-4">
      <label className="block font-bold text-gray-700">
        ✏️ Description de {nomObjet}
      </label>
      <textarea
        className="w-full h-24 border border-gray-400 rounded p-2"
        placeholder="Décris ici brièvement la tâche ou la procédure..."
        value={description}
        onChange={handleChange}
      />
      <button
        onClick={handleSave}
        className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700"
      >
        💾 Enregistrer la description
      </button>
    </div>
  );
};

export default BlocDocumentation;
