// src/pages/organisation/taches/ModifierTache.jsx
import React from "react";
export default function ModifierTache() {
  return <div>Formulaire de modification d’une tâche</div>;
}