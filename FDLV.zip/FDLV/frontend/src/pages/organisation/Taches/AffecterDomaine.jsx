// src/pages/organisation/taches/AffecterDomaine.jsx
import React from "react";
export default function AffecterDomaine() {
  return <div>Affectation d’une tâche à un domaine</div>;
}