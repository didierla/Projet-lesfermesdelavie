
import React from "react";

const CreerTacheEtendue = () => {
  return (
    <div className="max-w-4xl mx-auto mt-10 space-y-8">

      {/* Nom de la tâche */}
      <div className="p-6 bg-white shadow rounded border">
        <h2 className="text-xl font-bold mb-4">📝 Nom de la tâche</h2>
        <input
          type="text"
          className="w-full border rounded p-2"
          placeholder="Entrer le nom de la tâche"
        />
      </div>

      {/* Processus d'appartenance */}
      <div className="p-6 bg-white shadow rounded border">
        <h2 className="text-xl font-bold mb-4">📂 Processus d’appartenance</h2>
        <select className="w-full border rounded p-2 mb-2">
          <option value="">-- Sélectionner un processus --</option>
        </select>
        <div className="flex gap-2">
          <button className="bg-blue-600 text-white px-4 py-2 rounded">Créer un processus</button>
          <button className="bg-green-600 text-white px-4 py-2 rounded">Inscrire la tâche dans le processus</button>
        </div>
      </div>

      {/* Voile contextuel */}
      <div className="p-6 bg-white shadow rounded border">
        <h2 className="text-xl font-bold mb-4">🌫️ Voile contextuel actif</h2>
        <select className="w-full border rounded p-2">
          <option value="">-- Aucun --</option>
        </select>
      </div>

      {/* Informations entrantes */}
      <div className="p-6 bg-white shadow rounded border">
        <h2 className="text-xl font-bold mb-4">🔁 Informations entrantes</h2>
        <ul className="list-disc pl-5 text-gray-700 mb-4">
          <li>(à remplir dynamiquement)</li>
        </ul>
        <button className="bg-blue-500 text-white px-4 py-2 rounded">Intégrer une information</button>
      </div>

      {/* Informations sortantes */}
      <div className="p-6 bg-white shadow rounded border">
        <h2 className="text-xl font-bold mb-4">🔀 Informations sortantes</h2>
        <ul className="list-disc pl-5 text-gray-700 mb-4">
          <li>(à remplir dynamiquement)</li>
        </ul>
        <button className="bg-blue-500 text-white px-4 py-2 rounded">Intégrer une information</button>
      </div>

      {/* Objets entrants */}
      <div className="p-6 bg-white shadow rounded border">
        <h2 className="text-xl font-bold mb-4">📦 Objets entrants</h2>
        <ul className="list-disc pl-5 text-gray-700 mb-4">
          <li>(à remplir dynamiquement)</li>
        </ul>
        <button className="bg-blue-500 text-white px-4 py-2 rounded">Intégrer un objet</button>
      </div>

      {/* Compétences */}
      <div className="p-6 bg-white shadow rounded border">
        <h2 className="text-xl font-bold mb-4">🧠 Compétences nécessaires</h2>
        <ul className="list-disc pl-5 text-gray-700 mb-4">
          <li>(à remplir dynamiquement)</li>
        </ul>
        <div className="flex gap-2">
          <button className="bg-purple-600 text-white px-4 py-2 rounded">Créer une compétence</button>
          <button className="bg-indigo-600 text-white px-4 py-2 rounded">Affecter à la tâche</button>
        </div>
      </div>

      {/* Nombre de personnes */}
      <div className="p-6 bg-white shadow rounded border">
        <h2 className="text-xl font-bold mb-4">👥 Nombre de personnes requises</h2>
        <input
          type="number"
          min="1"
          className="w-full border rounded p-2"
          placeholder="Ex. : 2"
        />
      </div>

      {/* Boutons annexes */}
      <div className="p-6 bg-white shadow rounded border text-center space-y-2">
        <button className="bg-yellow-600 text-white px-4 py-2 rounded w-full">📘 Documentation sur wikivie.fr</button>
        <button className="bg-green-700 text-white px-4 py-2 rounded w-full">💬 Appeler l’IA pour obtenir une aide contextuelle</button>
      </div>

    </div>
  );
};

export default CreerTacheEtendue;
