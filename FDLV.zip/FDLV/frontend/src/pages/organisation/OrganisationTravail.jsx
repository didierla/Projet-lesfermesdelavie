// src/pages/organisation/OrganisationTravail.jsx
import React from "react";

export default function OrganisationTravail() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Gestion des Procédures et tâches</h1>
      <p>Page à compléter avec les fonctions à venir.</p>
    </div>
  );
}
