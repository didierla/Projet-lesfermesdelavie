// src/pages/organisation/GroupesSoutien.jsx
import React from "react";

export default function GroupesSoutien() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Gestion des Groupes de Soutien</h1>
      <p>Page à compléter avec les fonctions à venir.</p>
    </div>
  );
}
