import React from "react";

export default function GestionProcedures() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold mb-4">Gestion des Procédures</h2>
      <p>Ici vous pourrez structurer les procédures et étapes de travail associées à chaque tâche.</p>
    </div>
  );
}
