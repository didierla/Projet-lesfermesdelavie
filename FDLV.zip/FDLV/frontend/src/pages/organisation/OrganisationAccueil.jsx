import { Link } from "react-router-dom";

export default function OrganisationAccueil() {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Organisation du travail</h2>
      <ul className="space-y-3">
        <li>
          <Link to="/organisation/creer-tache" className="text-blue-600 hover:underline">
            ➕ Créer une tâche
          </Link>
        </li>
        <li>
          <Link to="/organisation/taches" className="text-blue-600 hover:underline">
            📋 Liste des tâches
          </Link>
        </li>
        <li>
          <Link to="/organisation/procedures" className="text-blue-600 hover:underline">
            📚 Voir les procédures
          </Link>
        </li>
      </ul>
    </div>
  );
}
