// frontend/src/pages/Connexion/Connexion.jsx
import React from "react";

export default function Connexion() {
  return (
    <div className="p-8">
      <h2 className="text-2xl font-bold mb-4">Connexion</h2>
      <p>Connexion à la gestion de projet des Fermes de la vie.</p>
    </div>
  );
}
