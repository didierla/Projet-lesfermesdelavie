import React from "react";
import { Link } from "react-router-dom";

export default function TourDeControle() {
  return (
    <div className="max-w-4xl mx-auto p-6 bg-white shadow-md rounded">
      <h1 className="text-3xl font-bold mb-6 text-center">Tour de Contrôle</h1>

      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-2 text-blue-800">Organisation du travail</h2>
        <ul className="list-disc list-inside space-y-1">
          <li>
            <Link to="/organisation/gestion-taches" className="text-blue-600 hover:underline">
              Gestion des tâches
            </Link>
          </li>
          <li>
            <Link to="/organisation/gestion-procedures" className="text-blue-600 hover:underline">
              Gestion des procédures
            </Link>
          </li>
        </ul>
      </div>

      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-2 text-green-800">Relations et soutien</h2>
        <ul className="list-disc list-inside space-y-1">
          <li>
            <Link to="/organisation/gestion-groupes-soutien" className="text-blue-600 hover:underline">
              Gestion des groupes de soutien
            </Link>
          </li>
          <li>
            <Link to="/organisation/gestion-relations-interfermes" className="text-blue-600 hover:underline">
              Gestion des relations interFermes
            </Link>
          </li>
        </ul>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-2 text-purple-800">Humains</h2>
        <ul className="list-disc list-inside space-y-1">
          <li>
            <Link to="/organisation/gestion-humains" className="text-blue-600 hover:underline">
              Gestion des humains
            </Link>
          </li>
        </ul>
      </div>
    </div>
  );
}
