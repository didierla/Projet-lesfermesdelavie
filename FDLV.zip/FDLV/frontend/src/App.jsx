import React, { useState } from "react";
import CreerTache from "./pages/organisation/Taches/CreerTache.jsx";
import AfficherTache from "./pages/organisation/Taches/AfficherTache.jsx";


function App() {
  const [tacheCreee, setTacheCreee] = useState(null);

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <CreerTache onTacheCreee={setTacheCreee} />
      {tacheCreee && (
        <>
          <h2 className="text-xl text-center mt-10 font-semibold text-gray-800">
            Tâche enregistrée :
          </h2>
          <AfficherTache tache={tacheCreee} />
        </>
      )}
    </div>
  );
}

export default App;
