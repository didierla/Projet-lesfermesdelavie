import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";

import TourDeControle from "./pages/TourDeControle";
import OrganisationTravail from "./pages/organisation/OrganisationTravail";
import GestionTaches from "./pages/organisation/Taches/GestionTaches";
import CreerTache from "./pages/organisation/taches/CreerTache";
import ModifierTache from "./pages/organisation/taches/ModifierTache";
import SupprimerTache from "./pages/organisation/taches/SupprimerTache";
import AffecterFermier from "./pages/organisation/taches/AffecterFermier";
import ListeFermier from "./pages/organisation/taches/ListeFermier";
import ListeProcedure from "./pages/organisation/taches/ListeProcedure";
import AffecterProcedure from "./pages/organisation/taches/AffecterProcedure";
import RetirerProcedure from "./pages/organisation/taches/RetirerProcedure";
import AffecterDomaine from "./pages/organisation/taches/AffecterDomaine";
import RetirerDomaine from "./pages/organisation/taches/RetirerDomaine";

export default function App() {
  return (
    <Routes>
      {/* 🔁 Redirection automatique à l'ouverture */}
      <Route path="/" element={<Navigate to="/organisation/taches" />} />
	  <Route path="/" element={<TourDeControle />} />
      {/* Pages principales */}
      <Route path="/tour-de-controle" element={<TourDeControle />} />
      <Route path="/organisation" element={<OrganisationTravail />} />
      <Route path="/organisation/taches" element={<GestionTaches />} />

      {/* Pages liées aux tâches */}
      <Route path="/organisation/taches/creer" element={<CreerTache />} />
      <Route path="/organisation/taches/modifier" element={<ModifierTache />} />
      <Route path="/organisation/taches/supprimer" element={<SupprimerTache />} />
      <Route path="/organisation/taches/affecter-fermier" element={<AffecterFermier />} />
      <Route path="/organisation/taches/liste-fermier" element={<ListeFermier />} />
      <Route path="/organisation/taches/liste-procedure" element={<ListeProcedure />} />
      <Route path="/organisation/taches/affecter-procedure" element={<AffecterProcedure />} />
      <Route path="/organisation/taches/retirer-procedure" element={<RetirerProcedure />} />
      <Route path="/organisation/taches/affecter-domaine" element={<AffecterDomaine />} />
      <Route path="/organisation/taches/retirer-domaine" element={<RetirerDomaine />} />
    </Routes>
  );
}

<div className="text-red-500 text-3xl font-bold text-center">
  Test visuel Tailwind
</div>