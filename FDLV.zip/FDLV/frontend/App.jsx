import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";


export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Connexion />} />
        <Route path="/inscription" element={<Inscription />} />
		    <Route path="/organisation-travail" element={<OrganisationTravail />} />
		    <Route path="/gestion-taches" element={<GestionTaches />} />
		    <Route path="/gestion-procedures" element={<GestionProcedures />} />
      </Routes>
    </Router>
  );
}
