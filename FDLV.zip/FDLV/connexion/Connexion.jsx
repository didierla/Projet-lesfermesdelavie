// src/pages/Connexion.jsx
import React from "react";
import { Link, useNavigate } from "react-router-dom";

export default function Connexion() {
  const navigate = useNavigate();

  const handleConnexion = (e) => {
    e.preventDefault();
    // Simulation de la connexion
    navigate("/accueil");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-blue-100 to-blue-300">
      <div className="bg-white p-10 rounded-2xl shadow-xl w-full max-w-md">
        <h1 className="text-2xl font-bold mb-6 text-center">Connexion aux Fermes de la Vie</h1>
        <form onSubmit={handleConnexion}>
          <div className="mb-4">
            <label className="block text-gray-700">Adresse email</label>
            <input
              type="email"
              required
              className="w-full px-4 py-2 mt-2 border rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="mb-6">
            <label className="block text-gray-700">Mot de passe</label>
            <input
              type="password"
              required
              className="w-full px-4 py-2 mt-2 border rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            type="submit"
            className="w-full bg-blue-500 text-white py-2 rounded-xl hover:bg-blue-600 transition"
          >
            Se connecter
          </button>
        </form>
        <div className="mt-6 text-center space-y-2">
          <Link to="/mot-de-passe-oublie" className="text-blue-600 hover:underline block">
            Mot de passe oublié ?
          </Link>
          <Link to="/creer-compte" className="text-green-600 hover:underline block">
            Créer un compte
          </Link>
          <Link to="/presentation" className="text-gray-600 hover:underline block">
            Découvrir sans se connecter
          </Link>
        </div>
      </div>
    </div>
  );
}
