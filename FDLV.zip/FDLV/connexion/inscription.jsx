import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Inscription() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    nom: "",
    email: "",
    motDePasse: "",
    confirmation: "",
  });
  const [erreur, setErreur] = useState("");
  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErreur("");
    setMessage("");

    if (formData.motDePasse !== formData.confirmation) {
      setErreur("Les mots de passe ne correspondent pas.");
      return;
    }

    try {
      const res = await fetch("http://localhost:8001/api/inscription", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          nom: formData.nom,
          email: formData.email,
          motDePasse: formData.motDePasse,
        }),
      });

      if (res.ok) {
        setMessage("Compte créé avec succès. Connectez-vous.");
        setTimeout(() => navigate("/"), 2000);
      } else {
        const data = await res.json();
        setErreur(data.erreur || "Erreur lors de la création du compte.");
      }
    } catch (err) {
      console.error(err);
      setErreur("Erreur de réseau ou serveur injoignable.");
    }
  };

  return (
    <div className="max-w-md mx-auto mt-12 bg-white p-6 rounded shadow">
      <h2 className="text-2xl font-bold mb-6 text-center">Créer un compte</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="nom"
          placeholder="Nom"
          value={formData.nom}
          onChange={handleChange}
          className="w-full mb-4 p-2 border rounded"
          required
        />
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={formData.email}
          onChange={handleChange}
          className="w-full mb-4 p-2 border rounded"
          required
        />
        <input
          type="password"
          name="motDePasse"
          placeholder="Mot de passe"
          value={formData.motDePasse}
          onChange={handleChange}
          className="w-full mb-4 p-2 border rounded"
          required
        />
        <input
          type="password"
          name="confirmation"
          placeholder="Confirmez le mot de passe"
          value={formData.confirmation}
          onChange={handleChange}
          className="w-full mb-4 p-2 border rounded"
          required
        />
        <button
          type="submit"
          className="w-full bg-green-500 text-white py-2 rounded hover:bg-green-600"
        >
          S'inscrire
        </button>
        {erreur && <p className="text-red-500 mt-4">{erreur}</p>}
        {message && <p className="text-green-500 mt-4">{message}</p>}
      </form>
    </div>
  );
}
